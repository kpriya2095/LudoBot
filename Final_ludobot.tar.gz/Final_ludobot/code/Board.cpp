#include <bits/stdc++.h>
#include <string>
using namespace std;
int arr[15][15];
bool draw_mode, rep;
vector<pair<int,int> >path[4];
int curr[4][4]={{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1}};
int temp[4][4]={{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1}};
int safe[]={1,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,1,1,1,1,1,1};
int board[15][15];
int isvalid(int dis,int player)
{
    int x=path[player][dis].first;
    int y=path[player][dis].second;
    if(dis>56)
        return 0;
    if(player==0)
    {
        if(board[x][y]>0)
        {
            if(board[x][y]>=1&&board[x][y]<=4)
                return 0;
        }
    }
    if(player==1)
    {
        if(board[x][y]>0)
        {
            if(board[x][y]>=5 && board[x][y]<=8)
                return 0;
        }
    }
    if(player==2)
    {
        if(board[x][y]>0)
        {
            if(board[x][y]>=9 && board[x][y]<=12)
                return 0;
        }
    }
    if(player==3)
    {
        if(board[x][y]>0)
        {
            if(board[x][y]>=13 && board[x][y]<=16)
                return 0;
        }
    }
    return 1;
}
void init()
{
    int i,j;
    for(i=0;i<15;i++)
    {
        for(j=0;j<15;j++)
            board[i][j]=0;
    }
}
void updateBoard()
{
    int i,j,p,x,y,k=0;
    init();
    for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
        {
            if(curr[i][j]!=-1)
            {
                p=k+j+1;
                x=path[i][curr[i][j]].first;
                y=path[i][curr[i][j]].second;
                board[x][y]=p;
            }
        }
        k=k+4;
    }
    //if(draw_mode) {
    if(true) {
        for(i=0;i<15;i++)
        {
            for(j=0;j<15;j++)
            {
                if(!(i==6||i==7||i==8||j==6||j==7||j==8))
                    cerr<<'.'<<" ";
                else
                    cerr<<board[j][i]<<" ";
            }
            cerr<<endl;
        }
    }
    cerr << "Player pos\n";
    for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
            cerr<<curr[i][j]<<" ";
        cerr<<endl;
    }
}
void generateAllPossible(int player,int dice)
{
    if(curr[player][0]!=-1)
        temp[dice][0]+=dice;
    if(curr[player][0]!=-1)
        temp[dice][1]+=dice;
    if(curr[player][0]!=-1)
        temp[dice][2]+=dice;
    if(curr[player][0]!=-1)
        temp[dice][3]+=dice;
}
int can_attack(int dis,int player)
{
    int x,y;
    x=path[player][dis].first;
    y=path[player][dis].second;
    if(player==0)
    {
        if(board[x][y]>0)
        {
            if(board[x][y]>4 && safe[curr[((board[x][y]-1)/4)][((board[x][y]-1)%4)]]!=1)
                return board[x][y];
        }
    }
    if(player==1)
    {
        if(board[x][y]>0)
        {
            if(board[x][y]>=1 && board[x][y]<=4 && safe[curr[((board[x][y]-1)/4)][((board[x][y]-1)%4)]]!=1)
                return board[x][y];
            if(board[x][y]>=9 && board[x][y]<=16 && safe[curr[((board[x][y]-1)/4)][((board[x][y]-1)%4)]]!=1)
                return board[x][y];
        }
    }
    if(player==2)
    {
        if(board[x][y]>0)
        {
            if(board[x][y]>=1 && board[x][y]<=8 && safe[curr[((board[x][y]-1)/4)][((board[x][y]-1)%4)]]!=1)
                return board[x][y];
            if(board[x][y]>=13 && board[x][y]<=16 && safe[curr[((board[x][y]-1)/4)][((board[x][y]-1)%4)]]!=1)
                return board[x][y];
        }
    }
    if(player==3)
    {
        if(board[x][y]>=0)
        {
            if(board[x][y]>=1 && board[x][y]<=12 && safe[curr[((board[x][y]-1)/4)][((board[x][y]-1)%4)]]!=1)
                return board[x][y];
        }
    }
    return 0;
}
string make_move(int player,int dice)
{
    int flag=0,x,i,p, j;
    string rs, temp1;
    char mmove[15] = {0};
    switch(player)
    {
        case 0:
        mmove[0] = 'Y';
        break;
        case 1:
        mmove[0] = 'B';
        break;
        case 2:
        mmove[0] = 'R';
        break;
        case 3:
        mmove[0] = 'G';
        break;
    }
    //cerr<<"dice to move "<<dice << endl;
    if(flag==0 && (dice==6||dice==1))
    {
        for(i=0;i<4;i++)
        {
            if(curr[player][i]==-1)
            {
                curr[player][i]=0;
                cerr << "Open move\n";
                cerr << "earlier board at this pos was :" << board[path[player][curr[player][i]].first][path[player][curr[player][i]].second] << endl;
                mmove[1] = i+'0';
                if(dice==1)
                    mmove[3] = '1';
                else {
                    mmove[3] = '6';
                }
                flag=1;
                break;
            }
        }
    }
    if(flag==0)
    {
        for(i=0;i<4;i++)
        {
            if(curr[player][i]!=-1 && curr[player][i]<56)
            {
              if(curr[player][i]+dice==56)
              {
                    //cerr<<"final"<<endl;
                  curr[player][i] = 56;
                  cerr << "home move\n";
                  cerr << "earlier board at this pos was :" << board[path[player][curr[player][i]].first][path[player][curr[player][i]].second] << endl;
                  mmove[1] = i+'0';
                  mmove[3] = dice + '0';
                  flag=1;
                  rep = true;
                  break;
              }
              else if(safe[curr[player][i]+dice]==1 && isvalid(curr[player][i]+dice,player))
              {
                  curr[player][i]+=dice;
                  flag=1;cerr << "safe move\n";
                  cerr << "earlier board at this pos was :" << board[path[player][curr[player][i]].first][path[player][curr[player][i]].second] << endl;
                  mmove[1] = i+'0';
                  mmove[3] = dice + '0';
                  
                  break;
              }
            }
        }
    }
    if(flag==0)
    {
        for(i=0;i<4;i++)
        {
            if(curr[player][i]!=-1 && curr[player][i]<56) {
                if(can_attack(curr[player][i]+dice,player))
                {
                    //cerr<<"can_attack"<<endl;
                    p=can_attack(curr[player][i]+dice,player);
                    p=p-1;
                    curr[p/4][p%4]=-1;
                    curr[player][i]+=dice;
                    cerr << "attack move\n";
                    cerr << "earlier board at this pos was :" << board[path[player][curr[player][i]].first][path[player][curr[player][i]].second] << endl;
                    flag=1;
                    mmove[1] = i+'0';
                    mmove[3] = dice + '0';
                    rep = true;
                    
                    break;
                }
            }
        }
    }
    if(flag==0)
    {
        for(i=0;i<4;i++)
        {
            if(curr[player][i]!=-1 && isvalid(curr[player][i]+dice,player) && board[path[player][curr[player][i]+dice].first][path[player][curr[player][i]+dice].second]==0)
             {
                 curr[player][i]+=dice;
                 flag=1;
                 mmove[1] = i+'0';
                 mmove[3] = dice + '0';
                 cerr << "valid move\n";
                 cerr << "earlier board at this pos was :" << board[path[player][curr[player][i]].first][path[player][curr[player][i]].second] << endl;
                 break;
             }
        }
    }
    if(flag==0)
    {
        //assert(false);
        // flag must be 1 by now, this means you have done some mistake, there is no possible move, solve this situation.
        mmove[0] = 'N';
        mmove[1] = 'A';
        mmove[2] = '\0';
    }
    else {
        mmove[2] = '_';
        updateBoard();
    }
    rs = string(mmove);
    //cerr << "MY MOVE is " << rs << endl;
    return rs;
}
void make_move_str(int player,int tid, int dice)
{
    if(curr[player][tid]==-1)
        curr[player][tid]=0;
    else
        curr[player][tid]+=dice;
    int x, y, p;
    x=path[player][curr[player][tid]].first;
    y=path[player][curr[player][tid]].second;
    //cerr << "dis is x: " << x << " y: " << y << " dis: " << curr[player][tid] << " dice: "<< dice <<endl;
    if(board[x][y]>0)
    {
        p = can_attack(curr[player][tid], player);
        if(p!=0)
        {
            p--;
            curr[p/4][p%4]=-1;
        }
    }
    updateBoard();
}
int main()
{
    {//yellow path
        int i,dice,player,x,k;
        for(i=1;i<=5;i++)
            path[0].push_back(make_pair(i,6));
        for(i=5;i>=1;i--)
            path[0].push_back(make_pair(6,i));
        for(i=6;i<=8;i++)
            path[0].push_back(make_pair(i,0));
        for(i=1;i<=5;i++)
            path[0].push_back(make_pair(8,i));
        for(i=9;i<=13;i++)
            path[0].push_back(make_pair(i,6));
        for(i=6;i<=8;i++)
            path[0].push_back(make_pair(14,i));
        for(i=13;i>=9;i--)
            path[0].push_back(make_pair(i,8));
        for(i=9;i<=13;i++)
            path[0].push_back(make_pair(8,i));
        for(i=8;i>=6;i--)
            path[0].push_back(make_pair(i,14));
        for(i=13;i>=9;i--)
            path[0].push_back(make_pair(6,i));
        for(i=5;i>=0;i--)
            path[0].push_back(make_pair(i,8));
        for(i=0;i<=6;i++)
            path[0].push_back(make_pair(i,7));
        //blue path
        for(i=1;i<=5;i++)
            path[1].push_back(make_pair(8,i));
        for(i=9;i<=13;i++)
            path[1].push_back(make_pair(i,6));
        for(i=6;i<=8;i++)
            path[1].push_back(make_pair(14,i));
        for(i=13;i>=9;i--)
            path[1].push_back(make_pair(i,8));
        for(i=9;i<=13;i++)
            path[1].push_back(make_pair(8,i));
        for(i=8;i>=6;i--)
            path[1].push_back(make_pair(i,14));
        for(i=13;i>=9;i--)
            path[1].push_back(make_pair(6,i));
        for(i=5;i>=1;i--)
            path[1].push_back(make_pair(i,8));
        for(i=8;i>=6;i--)
            path[1].push_back(make_pair(0,i));
        for(i=1;i<=5;i++)
            path[1].push_back(make_pair(i,6));
        for(i=5;i>=0;i--)
            path[1].push_back(make_pair(6,i));
        for(i=0;i<=6;i++)
            path[1].push_back(make_pair(7,i));
        //red path
        for(i=13;i>=9;i--)
            path[2].push_back(make_pair(i,8));
        for(i=9;i<=13;i++)
            path[2].push_back(make_pair(8,i));
        for(i=8;i>=6;i--)
            path[2].push_back(make_pair(i,14));
        for(i=13;i>=9;i--)
            path[2].push_back(make_pair(6,i));
        for(i=5;i>=1;i--)
            path[2].push_back(make_pair(i,8));
        for(i=6;i<=8;i++)
            path[2].push_back(make_pair(0,i));
        for(i=1;i<=5;i++)
            path[2].push_back(make_pair(i,6));
        for(i=5;i>=1;i--)
            path[2].push_back(make_pair(6,i));
        for(i=8;i>=6;i--)
            path[2].push_back(make_pair(i,0));
        for(i=1;i<=5;i++)
            path[2].push_back(make_pair(8,i));
        for(i=9;i<=14;i++)
            path[2].push_back(make_pair(i,6));
        for(i=14;i>=8;i--)
            path[2].push_back(make_pair(i,7));
        //green path
        for(i=13;i>=9;i--)
            path[3].push_back(make_pair(6,i));
        for(i=5;i>=1;i--)
            path[3].push_back(make_pair(i,8));
        for(i=8;i>=6;i--)
            path[3].push_back(make_pair(0,i));
        for(i=1;i<=5;i++)
            path[3].push_back(make_pair(i,6));
        for(i=5;i>=1;i--)
            path[3].push_back(make_pair(6,i));
        for(i=6;i<=8;i++)
            path[3].push_back(make_pair(i,0));
        for(i=1;i<=5;i++)
            path[3].push_back(make_pair(8,i));
        for(i=9;i<=13;i++)
            path[3].push_back(make_pair(i,6));
        for(i=6;i<=8;i++)
            path[3].push_back(make_pair(14,i));
        for(i=13;i>=9;i--)
            path[3].push_back(make_pair(i,8));
        for(i=9;i<=14;i++)
            path[3].push_back(make_pair(8,i));
        for(i=14;i<=8;i--)
            path[3].push_back(make_pair(7,i));
        updateBoard();}
    int time_limit, game_mode, pid, me, oth, dice, temp1, i;
    string move, tmp;

    vector<string> mmv;

    bool fl1=false;
    cin >> pid >> time_limit >> game_mode >> draw_mode;
    //cerr << "pid, tl, gm, draw " << pid << " " << time_limit << " " << game_mode << " " << draw_mode << endl;
    switch (game_mode)
    {
        case 0:
        if(pid==1)  {me = 2; oth = 0;}
        else if(pid==2) {me = 0; oth = 2;}
        break;
        case 1:
        if(pid==1)  {me = 1; oth = 3;}
        else if(pid==2) {me = 3; oth = 1;}
        break;
    }
    //cerr << "ME other "<< me << " "<< oth <<endl;
    if(pid==2)
    {
        // read other player's move
        getline(cin, tmp);
        //cin >> move;
        getline(cin, move);
        getline(cin, move);
        cerr << "Opposite moved: " << move << endl;
        if(!(move.size()>=2 && move[0]=='N' && move[1]=='A'))
            {
                i = 0;
                while(i+3<move.size()) {
                    cerr << "i is : "  << i << " " << move.size() << endl;
                    /*if(move[i]=='R' && move[i+1]=='E')
                        break;*/
                    cerr << "othe move is : "  << move[1+i]-'0' << " " << move[3+i]-'0' << endl;
                    make_move_str(oth, move[1+i]-'0', move[3+i]-'0');
                    i = i+10;
                }
            }
        cerr << "One cond done\n";
    }
    while(true)
    {
        rep = false;
        cout << "<THROW>\n";
        cin >> tmp;
        cin >> tmp;
        getline(cin, tmp);
        cerr << "We thrown is " << tmp << endl;
        dice = 0;
        temp1= 0;
        if(tmp.size()>=24)
        {
            mmv.push_back("NA\n");
        }
        else {
            do {
                while(tmp[temp1]<'1' || tmp[temp1]>'6') temp1++;
                dice = (tmp[temp1]-'0');
                temp1+=2;
                move = make_move(me, dice);
                cerr << "We moved: " << move << endl;
                mmv.push_back(move);
            } while(dice==6);
        }
        for(i=0; i<mmv.size(); i++) {
            if(i!=0) cout << "<next>";
            cout << mmv[i];
        }
        cout << endl;
        mmv.clear();
        //cerr << "Rep is : "<<rep<<endl;
        //if(rep) continue;
        //cin.fflush();
        do {
            getline(cin, move);
            cerr << "read tmp: "<< move <<endl;
            if(move.compare("REPEAT")==0)
                break;
            getline(cin, move);
            cerr << "read move: "<< move<<endl;
            if(!(move.size()>=2 && move[0]=='N' && move[1]=='A'))
            {
                i = 0;
                while(i+3<move.size()) {
                    cerr << "i is : "  << i << " " << move.size() << endl;
                    if(move[i]=='R' && move[i+1]=='E')
                        break;
                    cerr << "othe move is : "  << move[1+i]-'0' << " " << move[3+i]-'0' << endl;
                    make_move_str(oth, move[1+i]-'0', move[3+i]-'0');
                    i = i+10;
                }
            }
        }while(move.size()>4 && move[move.size()-1]=='T');
        cerr << "One loop done\n";
    }
    /*for(i=0;i<50;i++)
    {
        cin>>player>>dice;
        make_move(player,dice);
        cerr<<endl<<endl;
    }*/
    return 0;
}
